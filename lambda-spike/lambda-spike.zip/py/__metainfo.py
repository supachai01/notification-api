import py
pydir = py.path.local(py.__file__).dirpath()
