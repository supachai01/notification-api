#!/bin/bash
set -eo pipefail
pip install --target python -r requirements_for_user_flows.txt